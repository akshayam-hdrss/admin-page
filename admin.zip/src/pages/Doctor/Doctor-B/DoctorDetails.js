import React from 'react'

const DoctorDetails = () => {
  return (
    <>
        <div className="container">
            <h1 className="mt-4">Doctor Details Page</h1>
            <p>This is the Doctor Details page content.</p>
            <p>Here you can find detailed information about the doctor.</p>
        </div>
    </>
  )
}

export default DoctorDetails