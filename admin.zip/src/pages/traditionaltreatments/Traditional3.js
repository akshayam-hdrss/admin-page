import React from 'react'

export default function Traditional3() {
  return (
    <div>Traditional3</div>
  )
}
