import React from 'react'

const ComplaintsFeedback = () => {
  return (
    <div>ComplaintsFeedback</div>
  )
}

export default ComplaintsFeedback