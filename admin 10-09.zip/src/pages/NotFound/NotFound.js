import React from 'react';
export default function NotFound() {
  return <h1 style={{display:'flex', justifyContent:'center',height:'50vh',alignItems:'center'}}>404 - Page Not Found</h1>;
}
