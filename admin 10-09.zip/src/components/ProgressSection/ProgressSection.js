import React from 'react'

const ProgressSection = () => {
  return (
    <div>ProgressSection</div>
  )
}

export default ProgressSection